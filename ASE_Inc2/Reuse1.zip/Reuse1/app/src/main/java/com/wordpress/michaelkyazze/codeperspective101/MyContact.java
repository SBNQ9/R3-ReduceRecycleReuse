package com.wordpress.michaelkyazze.codeperspective101;

public class MyContact {

	public String name;
	public String category;
	public String price;
	public String phone;

}
