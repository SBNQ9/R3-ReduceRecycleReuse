package com.wordpress.michaelkyazze.codeperspective101;

import java.net.UnknownHostException;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import com.wordpress.michaelkyazze.codeperspective101.MongoHQ.SaveAsyncTask;

public class MainActivity extends Activity {
	EditText editText_category;
	EditText editText_phone;
	EditText editText_price;
	EditText editText_name;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

        editText_name = (EditText) findViewById(R.id.editText_name);
        editText_category = (EditText) findViewById(R.id.editText_category);
        editText_price = (EditText) findViewById(R.id.editText_price);
		editText_phone = (EditText) findViewById(R.id.editText_phone);

	}

	public void saveContact(View v) throws UnknownHostException {

		MyContact contact = new MyContact();
		contact.name = editText_name.getText().toString();
		contact.category = editText_category.getText().toString();
		contact.price = editText_price.getText().toString();
		contact.phone = editText_phone.getText().toString();

		SaveAsyncTask tsk = new SaveAsyncTask();
		tsk.execute(contact);

	}

}
